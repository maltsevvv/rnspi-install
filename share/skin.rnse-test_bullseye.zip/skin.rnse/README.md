## Обложка в стиле Audi Navigation RNS-E
![prototype scheme](https://github.com/maltsevvv/skin.rnse/blob/main/resources/icon.png)
![prototype scheme](https://github.com/maltsevvv/skin.rnse/blob/main/resources/list.png)
![prototype scheme](https://github.com/maltsevvv/skin.rnse/blob/main/resources/music.png)

[what changed](changelog.txt)

### Auto Install

1. Записать на sd-карту с образом Raspbian Buster Lite
2. Cкопировать `skin.rnsd-main.zip` или `skin.rnse-main.zip` на sd-карту в /boot/

`cd /tmp`  
`wget -q https://github.com/maltsevvv/rnspi-install/archive/main.zip`  
`unzip main.zip`  
`cd rnspi-install-main`  
`sudo sh install.sh`  
